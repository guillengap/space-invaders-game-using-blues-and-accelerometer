#include <Arduino.h>
#include <Notecard.h>
#include <NotecardPseudoSensor.h>

#include <Wire.h>
#include "MMA7660.h"
MMA7660 accelemeter;
void setup()
{
	accelemeter.init();  
	Serial.begin(9600);
}
void loop()
{
	int8_t x;
	int8_t y;
	int8_t z;
	float ax,ay,az;
	accelemeter.getXYZ(&x,&y,&z);
	//int val = y + 20;
	//int toSend = map (val, 0, 40, 0, 255);  
	//Serial.write(toSend);     

	//Serial.print("x = ");
    //Serial.println(x); 
    //Serial.print("y = ");
    //Serial.println(y);   
    //Serial.print("z = ");
    //Serial.println(z);
	
	accelemeter.getAcceleration(&ax,&ay,&az);
    /*Serial.println("accleration of X/Y/Z: ");
	Serial.print(ax);
	Serial.println(" g");
	Serial.print(ay);
	Serial.println(" g");
	Serial.print(az);
	Serial.println(" g");
	Serial.println("*************");*/

	// PING PONG CODE
//	int val = (ay * 100) + 100;
//	int toSend = map (val, 0, 200, 0, 255);
//	Serial.write(toSend);
//	delay(100);

	int btnval = 0;

	int valX = (ax * 100) + 200;
	int toSendX = map (valX, 100, 300, 50, 950);

	int valY = (ay * 100) + 200;
	int toSendY = map (valY, 100, 300, 950, 50);

  Serial.print(toSendX);//Dend xval value
  Serial.print(',');
  Serial.print(toSendY);//Dend yval value
  Serial.print(',');
  Serial.print(btnval);//Dend btnval value
  Serial.println(','); 
  delay(200);


	delay(100);
}