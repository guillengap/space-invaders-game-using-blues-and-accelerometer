// AUTHOR: GUILLERMO PEREZ GUILLEN
#include <Arduino.h>
#include <Notecard.h>
#include <NotecardPseudoSensor.h>

#include <Wire.h>
#include "MMA7660.h"
MMA7660 accelemeter;
void setup()
{
	accelemeter.init();  
	Serial.begin(9600);
}
void loop()
{
	int8_t x;
	int8_t y;
	int8_t z;
	float ax,ay,az;

	accelemeter.getXYZ(&x,&y,&z);
	accelemeter.getAcceleration(&ax,&ay,&az);

	int btnval = 0;

	int valX = (ax * 100) + 200;
	int toSendX = map (valX, 100, 300, 50, 950);

	int valY = (ay * 100) + 200;
	int toSendY = map (valY, 100, 300, 950, 50);

  Serial.print(toSendX);//Send xval value
  Serial.print(',');
  Serial.print(toSendY);//Send yval value
  Serial.print(',');
  Serial.print(btnval);//Send btnval value
  Serial.println(','); 
  delay(200);

  delay(100);
}